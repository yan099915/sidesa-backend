const express = require("express");
require("dotenv").config();
const connection = require("./database/database");
const bodyParser = require("body-parser");
const { PORT, NODE_ENV } = process.env;
const fs = require("fs");

const app = express();
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
// respond with "hello world" when a GET request is made to the homepage
app.get("/", (req, res) => {
  let files = fs.readdirSync("../");

  console.log(files, "files");
  res.json({ data: files });
});

module.exports = app;
