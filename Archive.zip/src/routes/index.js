// defines router
const UserRouter = require("./UsersRouters");

// export router
module.exports = {
  UserRouter,
};
